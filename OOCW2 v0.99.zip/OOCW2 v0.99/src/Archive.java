import java.util.LinkedList;
import java.util.List;


public class Archive {

	//List<WorkSchedule> schedule = new LinkedList<WorkSchedule>();
		
	/*public Archive(String startDate, String endDate){
		schedule.add(new WorkSchedule(startDate, endDate));
	}	*/
	
	//This was meant to be the archive where all the Work Schedules were stored
	//Unfortunately we couldn't get this sections working especially with the ENUMS
}