
public class Manager extends Driver {
	
	public Manager(String userName, String passWord){
		super(userName, passWord); 
	}
}
