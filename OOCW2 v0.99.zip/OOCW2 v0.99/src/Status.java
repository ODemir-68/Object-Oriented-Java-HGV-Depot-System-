
public enum Status {
PENDING, ACTIVE, CLOSED
}

//Using this was mentioned in the lecture over the easter holidays but we didn't have enough knowledge to implement this section for the comparisons (Also the Internet didn't help with explaining ENUMS)